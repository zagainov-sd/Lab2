﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp
{
    internal class My_Commands
    {
        public static RoutedCommand command1 { get; set; }
        public static RoutedCommand command2 { get; set; }
        static My_Commands()
        {
            command1 = new RoutedCommand("command1", typeof(MainWindow));
            command2 = new RoutedCommand("command2", typeof(MainWindow));
        }
        
    }
}
