﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Markup;
using ClassLibrary;
using OxyPlot;
using OxyPlot.Legends;
using OxyPlot.Series;

namespace WpfApp
{
    public class Graphics
    {
        public RawData raw_data { get; set; }
        public SplineData spline_data { get; set; }
        public LineSeries lineSeries { get; set; }
        public PlotModel plotModel { get; private set; }
        public Graphics() { }
        public Graphics(RawData raw_data, SplineData spline_data)
        {
            this.raw_data = raw_data;
            this.spline_data = spline_data;
            this.lineSeries = new LineSeries();
            this.plotModel = new PlotModel();
        }
        public void make_model()
        {
            var model = new PlotModel { Title = "Func" };
            for (int i = 0; i < spline_data.list.Count; ++i)
            {
                lineSeries.Points.Add(new DataPoint(spline_data.list[i].dot, spline_data.list[i].value));
            }
            lineSeries.Title = "Результат";
            lineSeries.Color = OxyColor.FromRgb(50, 50, 50);
            plotModel.Series.Add(lineSeries);

            ScatterSeries scatterSeries = new ScatterSeries { MarkerType = MarkerType.Circle };
            for (int i = 0; i < raw_data.amount_grid; i++)
            {
                int size = 5;
                int colorValue = 100;
                scatterSeries.Points.Add(new ScatterPoint(raw_data.nodes[i], raw_data.values[i], size, colorValue));
            }
            plotModel.Series.Add(scatterSeries);

            Legend legend = new Legend();
            plotModel.Legends.Add(legend);
        }
    }
}
