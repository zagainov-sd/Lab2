﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace WpfApp
{
    internal class ViewData : IDataErrorInfo
    {
        public double a { get; set; }
        public double b { get; set; }
        public int amount_grid { get; set; }
        public bool is_uniform_grid { get; set; }
        public bool is_nonuniform_grid { get; set; }
        public FRawEnum frawenum { get; set; }
        public FRaw fraw { get; set; }
        public double second_derivative_left { get; set; }
        public double second_derivative_right { get; set; }
        public int amount { get; set; }
        public string? load_file { get; set; }
        public string? save_file { get; set; }
        public string Error
        {
            get { return "Error Text"; }
        }

        public string this[string property]
        {
            get
            {
                string? msg = null;
                switch (property)
                {
                    case "amount_grid":
                        if (amount_grid < 2) msg = "Число узлов сетки должно быть больше или равно 2";
                        break;
                    case "amount":
                        if (amount <= 2) msg = "Число узлов равномерной сетки должно быть больше 2";
                        break;
                    case "a":
                        if (a > b) msg = "Левый конец отрезка должен быть меньше, чем правый конец отрезка";
                        break;
                    case "b":
                        if (a > b) msg = "Левый конец отрезка должен быть меньше, чем правый конец отрезка";
                        break;
                    default:
                        break;
                }
                return msg;
            }
        }


        public RawData rawdata;
        public SplineData splinedata;
        public ViewData()
        {
            this.a = 0;
            this.b = 1;
            this.amount_grid = 10;
            this.is_uniform_grid = true;
            this.is_nonuniform_grid = false;
            this.frawenum = FRawEnum.linear;
            this.second_derivative_left = 1;
            this.second_derivative_right = 1;
            this.amount = 20;

            this.load_file = null;
            this.save_file = null;

            this.rawdata = null;
        }
        public void ExecuteSplines_open()
        {
            try
            {
                splinedata = new SplineData(ref rawdata, second_derivative_left, second_derivative_right, amount);
                splinedata.ExecuteSplines();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void ExecuteSplines()
        {
            try
            {
                if (frawenum == FRawEnum.linear) fraw = RawData.linear;
                else if (frawenum == FRawEnum.cubic) fraw = RawData.cubic;
                else fraw = RawData.rand;
                
                if(is_uniform_grid)
                {
                    rawdata = new RawData(a, b, amount_grid, true, fraw);
                    rawdata.nodes = new double[amount_grid];
                    rawdata.values = new double[amount_grid];
                    for (int i = 0; i < rawdata.amount_grid; i++)
                    {
                        rawdata.nodes[i] = a + i * (b - a) / (amount_grid - 1);
                        rawdata.values[i] = rawdata.fraw(rawdata.nodes[i]);
                    }
                }
                else
                {
                    rawdata = new RawData(a, b, amount_grid, false, fraw);
                    rawdata.nodes = new double[amount_grid];
                    rawdata.values = new double[amount_grid];
                    Random rand = new Random();
                    rawdata.nodes[rawdata.values.Length - 1] = b;
                    rawdata.nodes[0] = a;
                    for (int i = 1; i < rawdata.amount_grid - 1; i++)
                    {
                        rawdata.nodes[i] = a + rand.NextDouble() * (b - a);
                    }
                    Array.Sort(rawdata.nodes);
                    for (int i = 0; i < rawdata.amount_grid; i++)
                    {
                        rawdata.values[i] = rawdata.fraw(rawdata.nodes[i]);
                    }
                }
                splinedata = new SplineData(ref rawdata, second_derivative_left, second_derivative_right, amount);
                splinedata.ExecuteSplines();
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void Save(string filename)
        {
            try
            {
                rawdata.Save(filename);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void Load(string filename)
        {
            try
            {
                RawData.Load(filename, out rawdata);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
