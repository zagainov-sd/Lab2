﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class SplineData
    {
        private RawData rawdata;
        private double second_derivative_left;
        private double second_derivative_right;
        public int amount;
        public List<SplineDataItem> list;
        public double integral_value;

        public SplineData(ref RawData _rawData, double _second_derivative_left, double _second_derivative_right, int _amount)
        {
            this.rawdata = _rawData;
            this.second_derivative_left = _second_derivative_left;
            this.second_derivative_right = _second_derivative_right;
            this.amount = _amount;
            this.list = new List<SplineDataItem>();
        }
        public void ExecuteSplines()
        {
            double[] grid = { rawdata.a, rawdata.b };
            double[] derivative2 = { second_derivative_left, second_derivative_right };
            double[] values = new double[1 * 3 * amount];
            double[] left_intergate_lim = new double[1] { rawdata.a };
            double[] right_intergate_lim = new double[1] { rawdata.b };
            double[] integrals = new double[1 * 1];
            int error_code = 0;
            make_spline(rawdata.values, rawdata.is_uniform_grid, rawdata.amount_grid, grid, rawdata.nodes, derivative2, amount, values, left_intergate_lim, right_intergate_lim, integrals, ref error_code);
            if(error_code != 0)
            {
                throw new Exception($"исключение = {error_code}");
            }
            double step = (rawdata.b - rawdata.a) / (amount - 1);
            for (int i = 0; i < values.Length / 3; ++i)
            {
                list.Add(new SplineDataItem(rawdata.a + step * i, values[i * 3], values[i * 3 + 1], values[i * 3 + 2]));
            }
            integral_value = integrals[0];

            [DllImport("C:\\prak\\Lab2\\x64\\Debug\\Dll.dll", CallingConvention = CallingConvention.Cdecl)]
            static extern void make_spline(double[] function_values, bool is_uniform_grid, int amount_grid, double[] grid_if_uniform, double[] grid_if_nonuniform, double[] derivative2, int dots_amount, double[] values, double[] left_intergate_lim, double[] right_intergate_lim, double[] integrals, ref int ret_error_code);

        }
    }
}
